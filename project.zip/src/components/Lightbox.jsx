import { useEffect, useState } from "react";
import "./Lightbox.css";

export default function Lightbox({ images = [], startIndex = 0, onClose }) {
  if (!images || images.length === 0) return null; // захист від undefined / пустого

  const [current, setCurrent] = useState(startIndex);

  const prev = () =>
      setCurrent((c) => (c === 0 ? images.length - 1 : c - 1));
  const next = () =>
      setCurrent((c) => (c === images.length - 1 ? 0 : c + 1));

  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [onClose]);

  // Lock scroll
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  return (
      <div className="lightbox" onClick={onClose}>
        <img
            src={images[current]}
            alt={`Restauration ${current + 1}`}
            className="lightbox__image"
            onClick={(e) => e.stopPropagation()}
        />
        <button className="lightbox__close" onClick={onClose}>
          ✕
        </button>
        <button
            className="lightbox__prev"
            onClick={(e) => {
              e.stopPropagation();
              prev();
            }}
        >
          ‹
        </button>
        <button
            className="lightbox__next"
            onClick={(e) => {
              e.stopPropagation();
              next();
            }}
        >
          ›
        </button>
      </div>
  );
}
