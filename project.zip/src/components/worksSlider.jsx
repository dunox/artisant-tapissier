import React, { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";

import "swiper/css";
import "swiper/css/pagination";
import "./worksSlider.css";
import Lightbox from "./Lightbox"; // компонент галереї
import { useResponsive } from "../hooks/useResponsive";

const worksImages = [
  "/src/assets/images/works/work-1.jpg",
  "/src/assets/images/works/work-2.jpg",
  "/src/assets/images/works/work-3.jpg",
  "/src/assets/images/works/work-4.jpg",
];

export const WorksSlider = () => {
  const { isMobile } = useResponsive();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [startIndex, setStartIndex] = useState(0);

  const openLightbox = (index) => {
    setStartIndex(index);
    setLightboxOpen(true);
  };

  return (
      <>
        <div className="worksSlider">
          <Swiper
              modules={[Autoplay, Pagination]}
              spaceBetween={16}
              slidesPerView={isMobile ? 1.2 : 2.5}
              centeredSlides={false}
              loop
              autoplay={{
                delay: 30000,
                disableOnInteraction: false,
              }}
              pagination={{ clickable: true }}
          >
            {worksImages.map((src, index) => (
                <SwiperSlide key={index}>
                  <div
                      className="slide"
                      onClick={() => openLightbox(index)}
                      style={{ cursor: "zoom-in" }}
                  >
                    <img
                        src={src}
                        alt={`Restauration ${index + 1}`}
                        loading="lazy"
                    />
                  </div>
                </SwiperSlide>
            ))}
          </Swiper>
        </div>

        {lightboxOpen && (
            <Lightbox
                images={worksImages}
                startIndex={startIndex}
                onClose={() => setLightboxOpen(false)}
            />
        )}
      </>
  );
};
