import "./Footer.css";

export default function Footer() {
  return (
      <footer id="footer" className="footer">
        <div className="footer__container container">
          <div className="footer__logo">
            <span>Jean-Pierre Wolf</span>
            <span>Artisan Tapissier</span>
          </div>
          {/*<div className="footer__contacts">*/}
          {/*  <p>Bourgoin-Jallieu, Isère, France</p>*/}
          {/*  <p>Tel: +33 6 12 34 56 78</p>*/}
          {/*  <p>Email: <a href="mailto:jeanpierre@example.com">jeanpierre@example.com</a></p>*/}
          {/*</div>*/}
          {/*<div className="footer__socials">*/}
          {/*  <a href="#" target="_blank" rel="noreferrer">Instagram</a>*/}
          {/*  <a href="#" target="_blank" rel="noreferrer">Facebook</a>*/}
          {/*  <a href="#" target="_blank" rel="noreferrer">TikTok</a>*/}
          {/*  <a href="#" target="_blank" rel="noreferrer">Google</a>*/}
          {/*</div>*/}
          <div className="footer__copy">
            &copy; {new Date().getFullYear()} Jean-Pierre Wolf. Tous droits réservés.
          </div>
        </div>
      </footer>
  );
}
