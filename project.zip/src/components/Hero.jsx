import "./Hero.css";

export default function Hero() {
  return (
      <section id="hero" className="hero">
        <div className="hero__overlay">
          <div className="hero__content">
            <span className="hero__badge">Depuis 1982</span>
            <h1>Jean-Pierre Wolf</h1>
            <p>Artisan Tapissier – Restauration et création de mobilier</p>
            <a href="#contact" className="btn-cta">
              Demandez un devis
            </a>
          </div>
        </div>
      </section>
  );
}
