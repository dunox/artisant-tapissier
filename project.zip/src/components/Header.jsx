import { useState, useEffect } from "react";
import "./Header.css";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNavClick = (id) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setOpen(false);
  };

  return (
      <header className={`header ${scrolled ? "header--scrolled" : ""}`}>
        <div className="header__inner container">
          <div className="logo" onClick={() => handleNavClick("#hero")}>
            <span className={`logo__name ${open ? "logo--active" : ""}`}>Jean-Pierre Wolf</span>
            <span className={`logo__subtitle ${open ? "logo--active" : ""}`}>Artisan Tapissier</span>
          </div>

          <button
              className={`burger ${open ? "is-open" : ""}`}
              onClick={() => setOpen(!open)}
              aria-label="Menu"
          >
            <span />
            <span />
            <span />
          </button>

          <nav className={`nav ${open ? "is-open" : ""}`}>
            <a onClick={() => handleNavClick("#about")}>À propos</a>
            <a onClick={() => handleNavClick("#services")}>Services</a>
            <a onClick={() => handleNavClick("#faq")}>FAQ</a>
            <a className="nav__cta" onClick={() => handleNavClick("#contact")}>
              Demandez un devis
            </a>
          </nav>

          {open && <div className="menu-overlay" onClick={() => setOpen(false)} />}
        </div>
      </header>
  );
}
