import { useRef } from "react";
import useAnimateOnScroll from "../hooks/useAnimateOnScroll";
import "./About.css";
import SectionTitle from "../elements/SectionTitle.jsx";
import aboutImage from "../assets/images/aboutMain.jpg";
export default function About() {
  const containerRef = useRef(null);
  useAnimateOnScroll(containerRef);

  return (
      <section id="about" className="about animate" ref={containerRef}>
        <SectionTitle title="A propos"/>
        <div className="about__container container">
          <div className="about__text">
            <h2>Un savoir-faire artisanal transmis par l’expérience</h2>
            <p>
              Artisan tapissier depuis 1982, je restaure et redonne vie aux meubles,
              fauteuils et sièges avec passion et exigence.
            </p>
            <p>
              Chaque pièce est travaillée dans le respect des techniques
              traditionnelles, des matériaux et de l’histoire du meuble.
            </p>
            <p>
              Mon atelier, situé à Bourgoin-Jallieu, accompagne particuliers et
              professionnels dans des projets sur mesure, durables et authentiques.
            </p>
          </div>
          <div className="about__image">
            <img
                src={aboutImage}
                alt="Jean-Pierre Wolf en atelier"
            />
          </div>
        </div>
      </section>
  );
}
