import "./Contact.css";
import {useRef} from "react";
import useAnimateOnScroll from "../hooks/useAnimateOnScroll.js";
import SectionTitle from "../elements/SectionTitle.jsx";
import SocialButtons from "../elements/SocialButtons.jsx";

export default function Contact() {
  const containerRef = useRef(null);
  useAnimateOnScroll(containerRef);

  return (
      <section id="contact" className="contact animate" ref={containerRef}>
        <div className="contact__container container">
          <SectionTitle title="Contactez-moi" color='light' />
          <p>Bourgoin-Jallieu, Isère, France</p>
          <p>Téléphone: +33 6 12 34 56 78</p>
          <p>Email: <a href="mailto:jeanpierre@example.com">jeanpierre@example.com</a></p>
          <SocialButtons />
        </div>
      </section>
  );
}
