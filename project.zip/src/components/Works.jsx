import { WorksSlider } from "./worksSlider.jsx";
import SectionTitle from "../elements/SectionTitle.jsx";


export default function Works() {
  return (
      <section className="works">
        <SectionTitle title="Réalisations" />
        <WorksSlider />
      </section>
  );
}
