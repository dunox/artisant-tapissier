import { useState, useRef, useEffect } from "react";
import "./FAQ.css";
import useAnimateOnScroll from "../hooks/useAnimateOnScroll.js";
import SectionTitle from "../elements/SectionTitle.jsx";

const faqItems = [
  {
    question: "Quels types de meubles restaurez-vous ?",
    answer: "Nous restaurons fauteuils, chaises, canapés, portes et meubles anciens avec un savoir-faire traditionnel. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  },
  {
    question: "Travaillez-vous sur des projets sur mesure ?",
    answer: "Oui, chaque projet est étudié sur mesure selon les besoins du client et l’histoire de la pièce."
  },
  {
    question: "Quels tissus utilisez-vous ?",
    answer: "Nous proposons un large choix de tissus et cuirs, en respectant les couleurs et les matières originales."
  },
  {
    question: "Combien de temps prend une restauration ?",
    answer: "Selon le type de meuble et l’état, la restauration peut varier de quelques jours à plusieurs semaines."
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(null);
  const refs = useRef([]);

  const toggle = (i) => {
    setOpenIndex(openIndex === i ? null : i);
  };

  useEffect(() => {
    // Підганяємо maxHeight під контент
    refs.current.forEach((ref, i) => {
      if (ref) {
        if (openIndex === i) {
          ref.style.maxHeight = ref.scrollHeight + "px";
        } else {
          ref.style.maxHeight = "0px";
        }
      }
    });
  }, [openIndex]);

  const containerRef = useRef(null);
  useAnimateOnScroll(containerRef);

  return (
      <section id="faq" className="faq animate" ref={containerRef}>
        <div className="faq__container container">
          <SectionTitle title="FAQ"/>
          <h2>Foire aux questions</h2>
          {faqItems.map((item, i) => (
              <div key={i} className="faq__item">
                <button className="faq__question" onClick={() => toggle(i)}>
                  <span className="faq__text">{item.question}</span>
                  <span className={`arrow ${openIndex === i ? "open" : ""}`} />
                </button>
                <div className="faq__answer" ref={(el) => (refs.current[i] = el)}>
                  <p>{item.answer}</p>
                </div>
              </div>
          ))}
        </div>
      </section>
  );
}
