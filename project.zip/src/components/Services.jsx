import SectionTitle from "../elements/SectionTitle";
import "./Services.css";
import {useRef} from "react";
import useAnimateOnScroll from "../hooks/useAnimateOnScroll.js";
import chairImg from '../assets/images/service_chaise.jpg'
import meublesImg from '../assets/images/service_meubles.jpg'
import porteImg from '../assets/images/service_porte.jpg'
import tapisImg from '../assets/images/service_tapis.jpg'

const services = [
  {
    title: "Fauteuils & chaises",
    desc: "Restauration traditionnelle et moderne, confort et respect des formes d’origine.",
    img: chairImg
  },
  {
    title: "Meubles anciens",
    desc: "Remise en état de meubles, structures bois et finitions soignées.",
    img: meublesImg
  },
  {
    title: "Portes & éléments décoratifs",
    desc: "Travail artisanal sur portes, panneaux et éléments tapissés.",
    img: porteImg
  },
  {
    title: "Tissus & tapisserie",
    desc: "Conseil, choix de tissus et confection sur mesure.",
    img: tapisImg
  },
];

export default function Services() {
  const containerRef = useRef(null);
  useAnimateOnScroll(containerRef);

  return (
      <section id="services" className="services animate" ref={containerRef}>
        <div className="container">
          <SectionTitle
              title="Mes services"
              subtitle="Un travail artisanal soigné, adapté à chaque pièce"
          />

          <div className="services__grid">
            {services.map((service, i) => (
                <div
                    key={i}
                    className="service-card"
                    style={{ backgroundImage: `url(${service.img})` }}
                >
                  <div className="service-card__overlay">
                    <h3>{service.title}</h3>
                    <p>{service.desc}</p>
                    <a href="#contact" className="btn-cta">
                      Demandez un devis
                    </a>
                  </div>
                </div>
            ))}
          </div>
        </div>
      </section>
  );
}
