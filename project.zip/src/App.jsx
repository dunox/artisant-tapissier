import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import "./styles/variables.css";
import "./styles/base.css";
import useSmoothScroll from "./hooks/useSmoothScroll.js";
import {useEffect} from "react";
import Works from "./components/Works.jsx";

function App() {
  useSmoothScroll();

  useEffect(() => {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const target = document.querySelector(link.getAttribute("href"));
        if (target) {
          target.scrollIntoView({ behavior: "smooth" });
        }
      });
    });
  }, []);


  return (
      <>
        <Header />
        <Hero />
        <About />
        <Services />
        <Works />
        <FAQ />
        <Contact />
        <Footer />
      </>
  );
}

export default App;
