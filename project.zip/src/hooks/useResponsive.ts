import { useEffect, useLayoutEffect, useState } from 'react';

export type Breakpoint = 'mobile' | 'tablet' | 'desktop';

interface ResponsiveState {
  breakpoint: Breakpoint;
  width: number;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
}

const getDeviceConfig = (width: number): Breakpoint => {
  if (width < 475.9) return 'mobile';
  if (width < 1024.9) return 'tablet';
  return 'desktop';
};

const useIsomorphicLayoutEffect =
  typeof window !== 'undefined' ? useLayoutEffect : useEffect;

// Throttle helper
function throttle<T extends (...args: any[]) => void>(func: T, limit: number): T {
  let inThrottle: boolean;
  let lastFunc: ReturnType<typeof setTimeout>;
  return function (this: any, ...args: any[]) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    } else {
      clearTimeout(lastFunc);
      lastFunc = setTimeout(() => {
        func.apply(this, args);
      }, limit);
    }
  } as T;
}

export const useResponsive = (): ResponsiveState => {
  const isClient = typeof window !== 'undefined';

  const getResponsiveState = (width: number): ResponsiveState => {
    const breakpoint = getDeviceConfig(width);
    return {
      breakpoint,
      width,
      isMobile: breakpoint === 'mobile',
      isTablet: breakpoint === 'tablet',
      isDesktop: breakpoint === 'desktop',
    };
  };

  const [state, setState] = useState<ResponsiveState>(() =>
    getResponsiveState(isClient ? window.innerWidth : 1024)
  );

  useIsomorphicLayoutEffect(() => {
    if (!isClient) return;

    const handleResize = throttle(() => {
      const width = window.innerWidth;
      setState(getResponsiveState(width));
    }, 150); // update max once every 150ms

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isClient]);

  return state;
}
