import "./SocialButtons.css";

import facebookIcon from '../assets/icons/facebook.svg';
import instagramIcon from '../assets/icons/instagram.svg';
import tiktokIcon from '../assets/icons/tiktok.svg';
import googleIcon from '../assets/icons/gmail.svg';

const socials = [
  { name: "Instagram", url: "#", icon: instagramIcon },
  { name: "Facebook", url: "#", icon: facebookIcon },
  { name: "TikTok", url: "#", icon: tiktokIcon },
  { name: "Google", url: "#", icon: googleIcon },
];

export default function SocialButtons({ className = "" }) {
  return (
      <div className={`social-buttons ${className}`}>
        {socials.map((social) => (
            <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noreferrer"
                className="social-buttons__link"
                title={social.name}
            >
              <img src={social.icon} alt=""/>
            </a>
        ))}
      </div>
  );
}
