import "./SectionTitle.css";

export default function SectionTitle({ title, color = "dark" }) {
  return (
      <div className={`section-title section-title--${color}`}>
        <h2>{title}</h2>
      </div>
  );
}
